Tarea 2 de Estructura de datos
=============================================
AMBIENTE DE EJECUCION USADO
--------------------------------------------------------------------
-sistema operativo: Linux Mint 21.3
--------------------------------------------------------------------
EJECUCIÓN
--------------------------------------------------------------------
La ejecución se hizo por consola usando los comandos en este orden:
Paso 1: asegurarse que esten en la misma carpeta Tarea_2_2.cpp y Peliculas.txt
Paso 2: dentro de la carpeta, en algun espacio en blanco hacer click derecho y elegir la opcion "abrir en una terminal"
en la terminal escribir los siguientes comandos
g++ Tarea_1.cpp -o run
./run
--------------------------------------------------------------------
CONSIDERACIONES AL MOMENTO DE EJECUTAR
--------------------------------------------------------------------
como se indica en el paso uno que Tarea_2_2.cpp y Peliculas.txt esten en la misma carpeta.
